package com.botindriver.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast

class BotService : AccessibilityService() {

    companion object {
        var instance: BotService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var fl: TextView? = null
    private var busyUntil = 0L
    private var pendingMin = -1.0
    private var pendingAt = 0L
    private var lastKey = ""
    private var lastCount = 0
    private var goingUp = false
    private var setTries = 0
    private val hidden = HashMap<String, Int>()

    private val tick = object : Runnable {
        override fun run() {
            try { step() } catch (e: Exception) { }
            if (Config.bool(this@BotService, "enabled", false)) h.postDelayed(this, 700)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Config.putBool(this, "enabled", false)
        showFloating()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        h.removeCallbacks(tick)
        try { fl?.let { wm?.removeView(it) } } catch (e: Exception) { }
        instance = null
        super.onDestroy()
    }

    // ---------- Botón flotante Modo ON / OFF ----------

    fun setEnabled(v: Boolean) {
        Config.putBool(this, "enabled", v)
        h.removeCallbacks(tick)
        if (v) {
            pendingMin = -1.0
            goingUp = false
            h.post(tick)
        }
        paint()
    }

    private fun paint() {
        val on = Config.bool(this, "enabled", false)
        fl?.text = if (on) "Modo ON" else "Modo OFF"
        fl?.setBackgroundColor(Color.parseColor(if (on) "#1F8A4C" else "#C93B3B"))
    }

    private fun showFloating() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.setPadding(40, 24, 40, 24)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 20
        lp.y = 300
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var downTime = 0L
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                    moved = false
                    downTime = System.currentTimeMillis()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = ox + dx
                        lp.y = oy + dy
                        wm?.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (System.currentTimeMillis() - downTime > 700) dump()
                        else setEnabled(!Config.bool(this, "enabled", false))
                    }
                }
            }
            true
        }
        fl = tv
        paint()
        wm?.addView(tv, lp)
    }

    // Mantén presionado el botón flotante: copia al portapapeles lo que ve el bot en pantalla.
    private fun dump() {
        val sb = StringBuilder()
        fun w(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null) return
            val b = Rect()
            n.getBoundsInScreen(b)
            sb.append(" ".repeat(d)).append(n.className).append(" | t=").append(n.text)
                .append(" | d=").append(n.contentDescription).append(" | id=").append(n.viewIdResourceName)
                .append(" | click=").append(n.isClickable).append(" | ").append(b.toShortString()).append("\n")
            for (i in 0 until n.childCount) w(n.getChild(i), d + 1)
        }
        w(rootInActiveWindow, 0)
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("diagnostico", sb.toString()))
        Toast.makeText(this, "Diagnóstico copiado", Toast.LENGTH_SHORT).show()
    }

    // ---------- Lógica principal ----------

    private fun busy(ms: Long) { busyUntil = System.currentTimeMillis() + ms }

    private fun step() {
        if (System.currentTimeMillis() < busyUntil) return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (!pkg.contains("indriver", true)) return
        val items = Parser.flatten(root)
        val texts = items.map { it.text }
        fun has(s: String) = texts.any { it.contains(s, true) }
        fun eq(s: String) = texts.any { it.equals(s, true) }

        // Viaje aceptado: el bot se detiene hasta que vuelva la lista.
        if (has("Cancelar viaje") && (has("Ya estoy aquí") || has("Ya llegué") || has("Iniciar viaje"))) {
            pendingMin = -1.0
            return
        }
        if (eq("Oferta") || texts.any { it.startsWith("Oferta del pasajero", true) }) {
            handleOffer(root, items)
            return
        }
        if (texts.any { it.startsWith("Aceptar por", true) }) {
            handleDetail(root, items)
            return
        }
        if (eq("Solicitudes de viaje")) handleList(root, items)
    }

    private fun handleList(root: AccessibilityNodeInfo, items: List<Item>) {
        val counter = items.firstNotNullOfOrNull { Regex("Ofertas enviadas:\\s*(\\d+)\\s*/\\s*(\\d+)").find(it.text) }
        val used = counter?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val max = counter?.groupValues?.get(2)?.toIntOrNull() ?: 3
        if (used >= max) return

        val maxPickup = Config.maxPickup(this)
        val allowStops = Config.bool(this, "stops", false)
        val cercado = Config.bool(this, "cercado", true)

        for (c in Parser.cards(items)) {
            if (c.green) continue
            val reason = when {
                c.pickupKm > maxPickup -> "recojo"
                c.hasStop && !allowStops -> "parada"
                blocked(c) -> "calle"
                else -> null
            }
            if (reason != null) {
                if (hide(c)) return else continue
            }
            if (cercado) {
                val st = Geo.status(this, c.addrA, c.addrB) ?: continue
                if (st) {
                    if (hide(c)) return else continue
                }
            }
            if (c.key == lastKey) {
                lastCount++
                if (lastCount > 2) continue
            } else {
                lastKey = c.key
                lastCount = 1
            }
            pendingMin = c.tripKm * Config.rateFor(this, c.tripKm)
            pendingAt = System.currentTimeMillis()
            if (!click(c.anchor)) tap(c.rect)
            busy(1200)
            return
        }
        scroll(root)
    }

    private fun handleDetail(root: AccessibilityNodeInfo, items: List<Item>) {
        if (items.any { it.text.contains("ya fue aceptada", true) }) {
            val close = items.firstOrNull { it.text.equals("Cerrar", true) }
            if (close != null) { clickItem(close); busy(900) }
            return
        }
        if (pendingMin < 0 || System.currentTimeMillis() - pendingAt > 40000) return
        val accept = items.first { it.text.startsWith("Aceptar por", true) }
        val p = Parser.num(accept.text.substringAfter("S/", ""))
        if (p != null && p >= pendingMin - 0.001) {
            clickItem(accept)
            pendingMin = -1.0
            busy(1500)
            return
        }
        val pencil = findPencil(root, items)
        if (pencil == null) {
            // Quizá el lápiz está fuera de pantalla: desliza la fila de precios.
            val row = items.filter { it.text.startsWith("S/") && !it.text.startsWith("Aceptar") }.maxByOrNull { it.r.left }
            if (row != null) scrollForward(row.node)
            busy(700)
            return
        }
        clickItem(pencil)
        setTries = 0
        busy(900)
    }

    private fun handleOffer(root: AccessibilityNodeInfo, items: List<Item>) {
        if (pendingMin < 0 || System.currentTimeMillis() - pendingAt > 60000) return
        val want = fmt(pendingMin)
        val field = findEdit(root)
        val btn = items.firstOrNull { it.text.equals("Oferta", true) }
        if (field == null || btn == null) return
        val cur = Parser.num((field.text?.toString() ?: "").replace("S/", ""))
        if (cur != null && Math.abs(cur - want.toDouble()) < 0.005) {
            clickItem(btn)
            pendingMin = -1.0
            setTries = 0
            busy(1500)
            return
        }
        setTries++
        if (setTries > 4) {
            setEnabled(false)
            Toast.makeText(this, "No pude escribir el precio. Bot apagado.", Toast.LENGTH_LONG).show()
            return
        }
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, want)
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        busy(500)
    }

    // ---------- Utilidades ----------

    private fun fmt(v: Double): String {
        val s = String.format(java.util.Locale.US, "%.2f", v)
        return if (s.endsWith(".00")) s.dropLast(3) else if (s.endsWith("0")) s.dropLast(1) else s
    }

    private fun blocked(c: Card): Boolean {
        val t = Config.norm(c.addrA + " " + c.addrB)
        return Config.blockWords(this).any { t.contains(it) }
    }

    private fun hide(c: Card): Boolean {
        if (hidden.size > 300) hidden.clear()
        val n = (hidden[c.key] ?: 0) + 1
        hidden[c.key] = n
        if (n > 3) return false
        val dm = resources.displayMetrics
        val y = c.rect.centerY().coerceIn(250, dm.heightPixels - 350)
        swipe(30, dm.widthPixels - 30, y)
        busy(900)
        return true
    }

    private fun scroll(root: AccessibilityNodeInfo) {
        val sc = findScrollable(root) ?: return
        if (goingUp) {
            if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) goingUp = false
        } else {
            if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) goingUp = true
        }
        busy(700)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val r = findScrollable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun scrollForward(n: AccessibilityNodeInfo?) {
        var c = n
        var i = 0
        while (c != null && i < 8) {
            if (c.isScrollable && c.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return
            c = c.parent
            i++
        }
    }

    private fun findEdit(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.className?.toString()?.contains("EditText") == true) return n
        for (i in 0 until n.childCount) {
            val r = findEdit(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun collectClickable(n: AccessibilityNodeInfo?, out: MutableList<Item>) {
        if (n == null) return
        if (n.isClickable && n.isVisibleToUser) {
            val r = Rect()
            n.getBoundsInScreen(r)
            val t = (n.text ?: n.contentDescription)?.toString() ?: ""
            out.add(Item(t, r, n))
        }
        for (i in 0 until n.childCount) collectClickable(n.getChild(i), out)
    }

    // El lápiz es el botón sin texto, a la derecha de los precios de "Ofrece tu tarifa".
    private fun findPencil(root: AccessibilityNodeInfo, items: List<Item>): Item? {
        val byDesc = items.firstOrNull {
            val t = it.text.lowercase()
            t.contains("editar") || t.contains("lápiz") || t.contains("personaliz") || t == "edit"
        }
        if (byDesc != null) return byDesc
        val label = items.firstOrNull { it.text.equals("Ofrece tu tarifa", true) } ?: return null
        val close = items.firstOrNull { it.text.equals("Cerrar", true) }
        val cl = ArrayList<Item>()
        collectClickable(root, cl)
        val c = cl.filter { x ->
            x.r.top >= label.r.bottom - 5 && x.r.width() > 40 &&
                (close == null || x.r.bottom <= close.r.top + 5) &&
                items.none { t -> t.node !== x.node && x.r.contains(t.r) }
        }
        if (c.isEmpty()) return null
        val top = c.minOf { it.r.top }
        return c.filter { Math.abs(it.r.top - top) < 40 }.maxByOrNull { it.r.left }
    }

    private fun click(n: AccessibilityNodeInfo?): Boolean {
        var c = n
        var i = 0
        while (c != null && i < 8) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            i++
        }
        return false
    }

    private fun clickItem(it: Item) {
        if (!click(it.node)) tap(it.r)
    }

    private fun swipe(x1: Int, x2: Int, y: Int) {
        val p = Path()
        p.moveTo(x1.toFloat(), y.toFloat())
        p.lineTo(x2.toFloat(), y.toFloat())
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 250)).build(), null, null)
    }

    private fun tap(r: Rect) {
        val p = Path()
        p.moveTo(r.centerX().toFloat(), r.centerY().toFloat())
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }
}
