package com.botindriver.app

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var tvAcc: TextView
    private lateinit var tvBat: TextView
    private lateinit var etMax: EditText
    private lateinit var cbStops: CheckBox
    private lateinit var cbCercado: CheckBox
    private lateinit var spSvc: Spinner
    private lateinit var etKey: EditText
    private lateinit var etBbox: EditText
    private lateinit var etBlock: EditText
    private lateinit var rulesBox: LinearLayout
    private val rows = ArrayList<Array<EditText>>()
    private val reqTxt = 41

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun head(s: String) {
        val t = TextView(this)
        t.text = s
        t.textSize = 18f
        t.setTypeface(null, Typeface.BOLD)
        t.setPadding(0, dp(20), 0, dp(6))
        box.addView(t)
    }

    private fun note(s: String): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = 13f
        box.addView(t)
        return t
    }

    private fun btn(s: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setOnClickListener { f() }
        box.addView(b)
        return b
    }

    private fun edit(hint: String, v: String, type: Int, lines: Int = 1): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(v)
        e.inputType = type
        if (lines > 1) {
            e.minLines = lines
            e.gravity = Gravity.TOP
        }
        box.addView(e)
        return e
    }

    private fun addRule(a: String, b: String, c: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val t = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        val vals = listOf(a, b, c)
        val es = Array(3) { i ->
            val e = EditText(this)
            e.inputType = t
            e.setText(vals[i])
            e.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            row.addView(e)
            e
        }
        val x = Button(this)
        x.text = "X"
        x.setOnClickListener {
            rulesBox.removeView(row)
            rows.remove(es)
        }
        row.addView(x)
        rulesBox.addView(row)
        rows.add(es)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(24), dp(16), dp(40))
        sv.addView(box)
        setContentView(sv)

        val title = TextView(this)
        title.text = "Bot InDriver"
        title.textSize = 24f
        title.setTypeface(null, Typeface.BOLD)
        box.addView(title)

        head("Permisos")
        tvAcc = note("")
        btn("Activar accesibilidad") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        tvBat = note("")
        btn("Quitar límite de batería") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        note("Si Accesibilidad sale bloqueada: Ajustes > Apps > Bot InDriver > menú ⋮ > Permitir configuración restringida.")

        head("Control")
        btn("Iniciar bot") {
            save()
            val s = BotService.instance
            if (s == null) toast("Primero activa la accesibilidad") else { s.setEnabled(true); toast("Bot encendido") }
        }
        btn("Detener bot") {
            BotService.instance?.setEnabled(false)
            toast("Bot apagado")
        }
        note("También puedes usar el botón flotante Modo ON / OFF. Mantenlo presionado para copiar un diagnóstico de la pantalla.")

        head("Recojo máximo (km)")
        etMax = edit("1.5", Config.str(this, "maxPickup", "1.5"), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)

        head("Paradas múltiples")
        cbStops = CheckBox(this)
        cbStops.text = "Permitir solicitudes con paradas"
        cbStops.isChecked = Config.bool(this, "stops", false)
        box.addView(cbStops)

        head("Zonas a evitar")
        cbCercado = CheckBox(this)
        cbCercado.text = "Ocultar solicitudes del Cercado de Arequipa"
        cbCercado.isChecked = Config.bool(this, "cercado", true)
        box.addView(cbCercado)
        spSvc = Spinner(this)
        spSvc.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("OpenStreetMap (gratis)", "Google Maps (requiere clave)"))
        spSvc.setSelection(if (Config.str(this, "service", "osm") == "google") 1 else 0)
        box.addView(spSvc)
        etKey = edit("Clave de Google Maps (solo si usas Google)", Config.str(this, "gkey", ""), InputType.TYPE_CLASS_TEXT)
        note("Límites del Cercado: lat mín, lat máx, lon mín, lon máx (aproximados, ajústalos si hace falta)")
        etBbox = edit("-16.411,-16.387,-71.552,-71.522", Config.str(this, "bbox", "-16.411,-16.387,-71.552,-71.522"), InputType.TYPE_CLASS_TEXT)
        note("Calles o palabras bloqueadas (una por línea)")
        etBlock = edit("Calle Peral", Config.str(this, "blocklist", "Calle Peral\nCalle Rivero\nCalle Consuelo"),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE, 5)
        btn("Importar lista (.txt)") {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "text/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(i, reqTxt)
        }

        head("Precio por rango de km")
        note("Desde / Hasta / S/ por km. Hasta = 0 significa sin límite.")
        rulesBox = LinearLayout(this)
        rulesBox.orientation = LinearLayout.VERTICAL
        box.addView(rulesBox)
        for (r in Config.rules(this)) addRule(r.from.toString(), r.to.toString(), r.rate.toString())
        btn("Agregar rango") { addRule("0", "0", "2.5") }

        head("Guardar")
        btn("Guardar configuración") { save(); toast("Guardado") }
    }

    override fun onResume() {
        super.onResume()
        val en = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        tvAcc.text = "Accesibilidad: " + if (en.contains(packageName, true)) "activada" else "falta activar"
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        tvBat.text = "Sin límite de batería: " + if (pm.isIgnoringBatteryOptimizations(packageName)) "activado" else "falta activar"
    }

    private fun save() {
        Config.put(this, "maxPickup", etMax.text.toString())
        Config.putBool(this, "stops", cbStops.isChecked)
        Config.putBool(this, "cercado", cbCercado.isChecked)
        Config.put(this, "service", if (spSvc.selectedItemPosition == 1) "google" else "osm")
        Config.put(this, "gkey", etKey.text.toString().trim())
        Config.put(this, "bbox", etBbox.text.toString())
        Config.put(this, "blocklist", etBlock.text.toString())
        val txt = rows.joinToString(";") { r ->
            r.joinToString(":") { e -> e.text.toString().replace(',', '.').ifBlank { "0" } }
        }
        Config.put(this, "rules", txt)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (requestCode == reqTxt && resultCode == RESULT_OK && u != null) {
            val t = contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() } ?: ""
            val cur = etBlock.text.toString().trim()
            etBlock.setText(if (cur.isEmpty()) t.trim() else cur + "\n" + t.trim())
        }
    }
}
