package com.botindriver.app

import android.content.Context
import java.text.Normalizer

class Rule(val from: Double, val to: Double, val rate: Double) // to = 0 significa sin límite

object Config {
    private fun sp(c: Context) = c.getSharedPreferences("bot", Context.MODE_PRIVATE)

    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun maxPickup(c: Context): Double =
        str(c, "maxPickup", "1.5").replace(',', '.').toDoubleOrNull() ?: 1.5

    fun rulesText(c: Context): String = str(c, "rules", "0:4:2.2;4:7:2.3;7:0:2.5")

    fun rules(c: Context): List<Rule> = rulesText(c).split(";").mapNotNull { part ->
        val x = part.split(":")
        if (x.size == 3) {
            val a = x[0].toDoubleOrNull()
            val b = x[1].toDoubleOrNull()
            val r = x[2].toDoubleOrNull()
            if (a != null && b != null && r != null) Rule(a, b, r) else null
        } else null
    }

    fun rateFor(c: Context, km: Double): Double {
        val l = rules(c)
        for (r in l) {
            if (r.to <= 0.0 || km <= r.to) return r.rate
        }
        return if (l.isNotEmpty()) l.last().rate else 0.0
    }

    fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "").trim()

    fun blockWords(c: Context): List<String> =
        str(c, "blocklist", "Calle Peral\nCalle Rivero\nCalle Consuelo")
            .split("\n").map { norm(it) }.filter { it.isNotEmpty() }
}
