package com.botindriver.app

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

class Item(val text: String, val r: Rect, val node: AccessibilityNodeInfo?)

class Card(
    val price: Double,
    val pickupKm: Double,
    val tripKm: Double,
    val hasStop: Boolean,
    val addrA: String,
    val addrB: String,
    val green: Boolean,
    val rect: Rect,
    val key: String,
    val anchor: AccessibilityNodeInfo?
)

object Parser {
    private val kmRe = Regex("^~?(\\d+(?:[.,]\\d+)?)\\s*km$", RegexOption.IGNORE_CASE)
    private val priceRe = Regex("^S/\\s*(\\d+(?:[.,]\\d+)?)$", RegexOption.IGNORE_CASE)
    private val numRe = Regex("^\\d+(?:[.,]\\d+)?$")
    private val ratingRe = Regex("^\\(?\\d+\\)?$")
    private val timeRe = Regex("^(\\d+\\s*(min|seg)\\.?|Justo ahora)$", RegexOption.IGNORE_CASE)
    private val stopRe = Regex("^\\d+\\s*paradas?$", RegexOption.IGNORE_CASE)
    private val tagRe = Regex("^(Yape|Plin|Efectivo|Precio justo|Oferta enviada)$", RegexOption.IGNORE_CASE)
    private val noise = setOf("solicitudes de viaje", "demanda", "desempeño")

    fun num(s: String): Double? {
        val m = Regex("(\\d+(?:[.,]\\d+)?)").find(s) ?: return null
        return m.groupValues[1].replace(',', '.').toDoubleOrNull()
    }

    fun flatten(root: AccessibilityNodeInfo): List<Item> {
        val out = ArrayList<Item>()
        walk(root, out)
        return out
    }

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<Item>) {
        if (n == null) return
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()
        if (!t.isNullOrEmpty() && n.isVisibleToUser) {
            val r = Rect()
            n.getBoundsInScreen(r)
            out.add(Item(t, r, n))
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), out)
    }

    // Une "S/" con el número que está a su derecha, por si InDriver los separa.
    private fun merge(items: List<Item>): List<Item> {
        val skip = BooleanArray(items.size)
        val extra = ArrayList<Item>()
        for (i in items.indices) {
            val a = items[i]
            if (!a.text.equals("S/", true)) continue
            var best = -1
            for (j in items.indices) {
                val b = items[j]
                if (skip[j] || !numRe.matches(b.text)) continue
                if (Math.abs(b.r.centerY() - a.r.centerY()) > 50 || b.r.left < a.r.left - 5) continue
                if (best < 0 || b.r.left < items[best].r.left) best = j
            }
            if (best >= 0) {
                skip[i] = true
                skip[best] = true
                val rr = Rect(a.r)
                rr.union(items[best].r)
                extra.add(Item("S/" + items[best].text, rr, a.node))
            }
        }
        val out = ArrayList<Item>()
        for (i in items.indices) if (!skip[i]) out.add(items[i])
        out.addAll(extra)
        return out
    }

    fun cards(raw: List<Item>): List<Card> {
        val items = merge(raw).sortedBy { it.r.top }
        val prices = items.filter { priceRe.matches(it.text) }
        val out = ArrayList<Card>()
        for (idx in prices.indices) {
            val p = prices[idx]
            val start = p.r.top - 130
            val end = if (idx + 1 < prices.size) prices[idx + 1].r.top - 130 else Int.MAX_VALUE
            val seg = items.filter { it.r.top >= start && it.r.top < end }
            val kms = seg.filter { kmRe.matches(it.text) }.sortedBy { it.r.top }
            if (kms.size < 2) continue
            val timeItem = seg.firstOrNull { timeRe.matches(it.text) }
            val addr = seg.filter { x ->
                x !== p && x.r.top > p.r.bottom - 5 &&
                    !kmRe.matches(x.text) && !priceRe.matches(x.text) && !tagRe.matches(x.text) &&
                    !timeRe.matches(x.text) && !stopRe.matches(x.text) && !ratingRe.matches(x.text) &&
                    !numRe.matches(x.text) && x.text.length >= 3 &&
                    !noise.contains(x.text.lowercase()) && !x.text.startsWith("Obtén") &&
                    (timeItem == null || Math.abs(x.r.centerY() - timeItem.r.centerY()) > 25)
            }
            val tripY = kms.last().r.centerY()
            val a = addr.filter { it.r.centerY() < tripY - 12 }.sortedBy { it.r.top }.joinToString(" ") { it.text }
            val b = addr.filter { it.r.centerY() >= tripY - 12 }.sortedBy { it.r.top }.joinToString(" ") { it.text }
            val rect = Rect(p.r)
            for (x in seg) rect.union(x.r)
            val price = num(p.text) ?: continue
            val pk = num(kms.first().text) ?: continue
            val tk = num(kms.last().text) ?: continue
            val stop = seg.any { stopRe.matches(it.text) }
            val green = seg.any { it.text.equals("Oferta enviada", true) }
            out.add(Card(price, pk, tk, stop, a, b, green, rect, "$price|$a|$b", p.node))
        }
        return out
    }
}
