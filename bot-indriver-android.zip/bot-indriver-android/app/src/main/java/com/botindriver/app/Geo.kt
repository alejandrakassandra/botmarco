package com.botindriver.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

// Detecta si una dirección cae en el Cercado de Arequipa.
// Usa OpenStreetMap (gratis, ~1 consulta por segundo) o Google Maps (con clave).
object Geo {
    private val cache = HashMap<String, Boolean>()
    private val pending = HashSet<String>()
    private val ex = Executors.newSingleThreadExecutor()

    // true = alguna de las dos direcciones está en el Cercado, false = ninguna, null = aún consultando
    fun status(c: Context, a: String, b: String): Boolean? {
        val ra = one(c, a)
        val rb = one(c, b)
        if (ra == null || rb == null) return null
        return ra || rb
    }

    private fun one(c: Context, addr: String): Boolean? {
        if (addr.isBlank()) return false
        synchronized(cache) {
            val v = cache[addr]
            if (v != null) return v
        }
        synchronized(pending) {
            if (pending.contains(addr)) return null
            pending.add(addr)
        }
        val app = c.applicationContext
        ex.execute {
            var res = false
            try {
                res = lookup(app, addr)
            } catch (e: Exception) {
                res = false
            }
            synchronized(cache) { cache[addr] = res }
            synchronized(pending) { pending.remove(addr) }
            try { Thread.sleep(1100) } catch (e: Exception) { }
        }
        return null
    }

    private fun lookup(c: Context, addr: String): Boolean {
        val q = URLEncoder.encode(addr.replace("(", ", ").replace(")", "") + ", Arequipa, Peru", "UTF-8")
        val google = Config.str(c, "service", "osm") == "google"
        val url = if (google)
            "https://maps.googleapis.com/maps/api/geocode/json?address=$q&key=" + Config.str(c, "gkey", "")
        else
            "https://nominatim.openstreetmap.org/search?q=$q&format=json&limit=1"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", "BotInDriver/1.0 (uso personal)")
        conn.connectTimeout = 6000
        conn.readTimeout = 6000
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        val lat: Double
        val lon: Double
        val name: String
        if (google) {
            val arr = JSONObject(body).getJSONArray("results")
            if (arr.length() == 0) return false
            val r = arr.getJSONObject(0)
            val loc = r.getJSONObject("geometry").getJSONObject("location")
            lat = loc.getDouble("lat")
            lon = loc.getDouble("lng")
            name = r.optString("formatted_address")
        } else {
            val arr = JSONArray(body)
            if (arr.length() == 0) return false
            val r = arr.getJSONObject(0)
            lat = r.getString("lat").toDouble()
            lon = r.getString("lon").toDouble()
            name = r.optString("display_name")
        }
        if (name.contains("Cercado", true) && name.contains("Arequipa", true)) return true
        val b = Config.str(c, "bbox", "-16.411,-16.387,-71.552,-71.522").split(",").map { it.trim().toDouble() }
        return lat >= b[0] && lat <= b[1] && lon >= b[2] && lon <= b[3]
    }
}
