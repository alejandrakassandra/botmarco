# Bot InDriver (Android)

App de Android con un servicio de accesibilidad que lee la pantalla de InDriver
y aplica tus reglas: recojo máximo, paradas, calles/zonas bloqueadas, precio por rango de km.

## Opción A: compilar el APK con GitHub (sin instalar nada)
1. Crea un repositorio en GitHub (puede ser privado) y sube TODO el contenido de esta carpeta
   (incluida la carpeta oculta `.github`).
2. Entra a la pestaña **Actions**. El flujo "Build APK" corre solo con cada subida
   (o pulsa **Run workflow**). Tarda unos 3 a 6 minutos.
3. Abre la ejecución terminada y baja el archivo **bot-indriver-apk** (es un zip con `app-debug.apk`).
4. Pásalo al teléfono e instálalo (permite "instalar apps desconocidas" si te lo pide).

## Opción B: compilar con Android Studio
1. Descomprime el zip. En Android Studio: **File > Open** y elige la carpeta `bot-indriver-android`.
2. Espera a que termine "Gradle sync" (descarga lo necesario, necesita internet).
3. Menú **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Cuando termine, pulsa **locate**: el archivo está en `app/build/outputs/apk/debug/app-debug.apk`.

## Primer uso
1. Abre **Bot InDriver** y pulsa **Activar accesibilidad**: busca "Bot InDriver" y actívalo.
   - En Android 13 o superior, si sale bloqueado: Ajustes > Apps > Bot InDriver > menú ⋮ >
     **Permitir configuración restringida**, y vuelve a intentarlo.
2. Pulsa **Quitar límite de batería** y acepta.
3. Configura tus reglas y pulsa **Guardar configuración**.
4. Abre InDriver. Aparece el botón flotante **Modo OFF**: tócalo para pasar a **Modo ON**.
   Se puede arrastrar. Si lo mantienes presionado, copia al portapapeles un diagnóstico
   de la pantalla actual (sirve para ajustar el bot si algo no funciona).

## Flujo del bot
Lista: lee "Ofertas enviadas X/3" y espera si está en 3/3 > revisa cada tarjeta (salta las verdes):
recojo mayor al máximo, parada no permitida, calle bloqueada, zona del Cercado (OpenStreetMap o Google)
> si cumple, entra > si el pasajero ofrece igual o más que tu mínimo pulsa Aceptar;
si no, pulsa el lápiz, escribe tu mínimo y pulsa Oferta > si sale "Cancelar viaje / Ya estoy aquí" se detiene
y se reactiva solo cuando vuelve la lista. Si no hay nada que hacer, baja por la lista y vuelve arriba.

## Notas importantes
- No pude compilar ni probar esta app en mi entorno: es la primera versión y es normal
  que haya que ajustar detalles con pruebas reales en tu teléfono.
- El bot lee los textos de InDriver. Si InDriver cambia su pantalla, hay que actualizar el bot.
- Los límites del Cercado son aproximados; ajústalos en la app si ves errores.
- InDriver puede considerar el uso de automatización como infracción de sus términos.
  Úsalo bajo tu responsabilidad.
