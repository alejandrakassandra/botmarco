#!/usr/bin/env bash
# Compila el APK dentro de un Codespace (o cualquier Linux con internet).
# Uso:  bash build-apk.sh
set -e
export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
mkdir -p "$ANDROID_HOME/cmdline-tools"

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
  echo ">> Descargando herramientas de Android..."
  curl -L -o /tmp/cmdline.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q -o /tmp/cmdline.zip -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
fi

echo ">> Aceptando licencias e instalando SDK 34..."
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "platforms;android-34" "build-tools;34.0.0"

cd "$(dirname "$0")"
echo "sdk.dir=$ANDROID_HOME" > local.properties

if ! command -v gradle > /dev/null 2>&1; then
  echo ">> Descargando Gradle 8.9..."
  curl -L -o /tmp/gradle.zip https://services.gradle.org/distributions/gradle-8.9-bin.zip
  unzip -q -o /tmp/gradle.zip -d "$HOME/gradle"
  export PATH="$HOME/gradle/gradle-8.9/bin:$PATH"
fi

echo ">> Compilando..."
gradle assembleDebug --no-daemon

mkdir -p dist
cp app/build/outputs/apk/debug/app-debug.apk dist/bot-indriver.apk
echo ""
echo "LISTO: dist/bot-indriver.apk"
echo "Clic derecho sobre ese archivo en el explorador de la izquierda > Download."
